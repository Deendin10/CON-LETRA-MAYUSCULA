const audio = document.getElementById('audioPlayer');
const playPauseBtn = document.getElementById('playPauseBtn');
const volumeControl = document.getElementById('volumeControl');
const songTitle = document.getElementById('songTitle');
const visualizer = document.getElementById('visualizer');
const leftBar = document.getElementById('leftBar');
const rightBar = document.getElementById('rightBar');

// Inicializar el volumen
audio.volume = 0.5;
volumeControl.value = 0.5;

// Play/Pause
playPauseBtn.addEventListener('click', () => {
    if (audio.paused) {
        audio.play();
        playPauseBtn.textContent = '⏸️';
    } else {
        audio.pause();
        playPauseBtn.textContent = '▶️';
    }
});

// Control de volumen
volumeControl.addEventListener('input', () => {
    audio.volume = volumeControl.value;
});

// Visualizar título de la canción
audio.addEventListener('play', () => {
    songTitle.textContent = "Reproduciendo: " + audio.src.split('/').pop();
});

// Visualizador de audio (vúmetro)
const audioContext = new (window.AudioContext || window.webkitAudioContext)();
const analyser = audioContext.createAnalyser();
const source = audioContext.createMediaElementSource(audio);
source.connect(analyser);
analyser.connect(audioContext.destination);
analyser.fftSize = 256;

const bufferLength = analyser.frequencyBinCount;
const dataArray = new Uint8Array(bufferLength);

// Función de dibujo del visualizador
function drawVisualizer() {
    analyser.getByteFrequencyData(dataArray);
    const width = visualizer.width;
    const height = visualizer.height;
    const barWidth = (width / bufferLength) * 2.5;
    let x = 0;

    // Dibuja las barras
    visualizer.getContext('2d').clearRect(0, 0, width, height);
    for (let i = 0; i < bufferLength; i++) {
        const barHeight = dataArray[i];
        visualizer.getContext('2d').fillStyle = 'rgb(' + (barHeight + 100) + ',50,50)';
        visualizer.getContext('2d').fillRect(x, height - barHeight, barWidth, barHeight);
        x += barWidth + 1;
    }
    requestAnimationFrame(drawVisualizer);
}

drawVisualizer();

// Vúmetro estéreo
function updateVumeter() {
    analyser.getByteFrequencyData(dataArray);

    let leftHeight = 0;
    let rightHeight = 0;

    // Dividir el array en dos partes para obtener los valores estéreo
    for (let i = 0; i < bufferLength / 2; i++) {
        leftHeight += dataArray[i];
        rightHeight += dataArray[i + bufferLength / 2];
    }

    // Escalar las alturas
    leftHeight = leftHeight / (bufferLength / 2);
    rightHeight = rightHeight / (bufferLength / 2);

    // Ajustar la altura de los vúmetros
    leftBar.style.height = `${Math.min(leftHeight / 2, 100)}px`;
    rightBar.style.height = `${Math.min(rightHeight / 2, 100)}px`;

    requestAnimationFrame(updateVumeter);
}

updateVumeter();
